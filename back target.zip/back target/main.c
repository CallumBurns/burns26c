#include "stm32f10x.h"
#include "init.h"
#include <stdio.h>


//main
int main(){
	
Clock_Init();
GPIO_init ();
LCD_IO_init();
LCD_Startup();
char mymessage1[30]="Strike!";//"1"; //"Strike!";	
char mymessage2[30]= "Ball!";//"2";//"Ball!";	
char mymessage3[50]= "-";	
char mymessage4[50] = "                    ";	//20 spaces
char mymessage5[50] = "1";	//20 spaces
char mymessage6[50] = "2";	//20 spaces
char mymessage7[50] = "3";	//20 spaces
char mymessage8[50] = "4";	//20 spaces
char mymessage9[50] = "5";	//20 spaces
char mymessage10[50] = "6";	//20 spaces
char mymessage11[50] = "7";	//20 spaces
char mymessage12[50] = "8";	//20 spaces
int i =-1;
int temp=0;
int32_t temp2 =0;
int time_delay = 18000000;

	
	
while(1){
	if (i==-1){
		GPIOB->ODR |=0X0000;
		delay(time_delay);
		//stringToLCD(mymessage5);
	//	stringToLCD(mymessage3);
			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
		stringToLCD(mymessage2);
		stringToLCD(mymessage3);
			}
		++i;
			
		}
	
	if (i==0){
		GPIOB->ODR &= 0XFFFF;
		GPIOB -> ODR &=0X0;
		GPIOB->ODR |=0X2400;
 		delay(time_delay);
	//	stringToLCD(mymessage6);
		//stringToLCD(mymessage3);
			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
		stringToLCD(mymessage2);
		stringToLCD(mymessage3);
		}
		++i;
	}
	
	if (i ==1){
		GPIOB ->ODR &=0xDBFF; // testing port b
		GPIOB ->ODR |=0X4800;
		delay(time_delay);
		//stringToLCD(mymessage7);
		//stringToLCD(mymessage3);
			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
		stringToLCD(mymessage2);
		stringToLCD(mymessage3);
		}
			++i;	
	}
		
	if (i ==2){
		GPIOB ->ODR &=0xB7FF; //problem
		GPIOB ->ODR |=0X6C00;

		delay(time_delay);
	//	stringToLCD(mymessage8);
	//	stringToLCD(mymessage3);
			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
		stringToLCD(mymessage1);
		stringToLCD(mymessage3);
		}
			++i;	
	}
	
	if (i ==3){
		GPIOB ->ODR &=0X93FF;
		GPIOB ->ODR |=0X9000;
		delay(time_delay);
	//	stringToLCD(mymessage9);
	//	stringToLCD(mymessage3);
		if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
		stringToLCD(mymessage1);
		stringToLCD(mymessage3);
		}
			++i;		
	}
	
	if (i ==4){
		GPIOB ->ODR &=0X6FFF;
		GPIOB ->ODR |=0XB400;

		delay(time_delay);
		//stringToLCD(mymessage10);
		//stringToLCD(mymessage3);
			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
		stringToLCD(mymessage1);
		stringToLCD(mymessage3);
		}
			++i;	
	}
	if (i ==5){
		GPIOB ->ODR &=0X4BFF; 
		GPIOB ->ODR |=0XD800;
		delay(time_delay);
		//stringToLCD(mymessage11);
		//stringToLCD(mymessage3);
			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
		stringToLCD(mymessage1);
		stringToLCD(mymessage3);
		}
			++i;	
	}
	if (i ==6){
		GPIOB ->ODR &=0X27FF;
		GPIOB ->ODR |=0XFC00;
		delay(time_delay);
		//stringToLCD(mymessage12);
		//stringToLCD(mymessage3);
			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
		stringToLCD(mymessage2);
		stringToLCD(mymessage3);
		}
		GPIOB ->ODR &=0X03FF;
		GPIOB ->ODR |=0x0000;
		
			int temp=-1;
			i=temp;

	}
	
	
//working before 
	
//		if (i==-1){
//		delay(time_delay);
//			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
//		stringToLCD(mymessage2);
//		stringToLCD(mymessage3);
//			}
//		++i;
//			
//		}
//	
//	if (i==0){
//	 GPIOB->ODR |=0X2000;
//		delay(time_delay);
//			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
//		stringToLCD(mymessage2);
//		stringToLCD(mymessage3);
//		}
//		++i;
//	}
//	
//	if (i ==1){
//		GPIOB ->ODR &=0XDFFF;
//		GPIOB ->ODR |=0X4000;
//		delay(time_delay);
//			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
//		stringToLCD(mymessage2);
//		stringToLCD(mymessage3);
//		}
//			++i;	
//	}
//		
//	if (i ==2){
//		GPIOB ->ODR &=0XBFFF;
//		GPIOB ->ODR |=0X6000;
//		delay(time_delay);
//			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
//		stringToLCD(mymessage2);
//		stringToLCD(mymessage3);
//		}
//		//stringToLCD(c);
//			++i;	
//	}
//	
//	if (i ==3){
//		GPIOB ->ODR &=0X9FFF;
//		GPIOB ->ODR |=0X8000;
//		delay(time_delay);
//		if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
//		stringToLCD(mymessage1);
//		stringToLCD(mymessage3);
//		}
//		//stringToLCD(d);
//			++i;		
//	}
//	
//	if (i ==4){
//		GPIOB ->ODR &=0X7FFF;
//		GPIOB ->ODR |=0XA000;
//		delay(time_delay);
//			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
//		stringToLCD(mymessage1);
//		stringToLCD(mymessage3);
//		}
//		//stringToLCD(e);
//			++i;	
//	}
//	if (i ==5){
//		GPIOB ->ODR &=0X9FFF;
//		GPIOB ->ODR |=0XC000;
//		delay(time_delay);
//			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
//		stringToLCD(mymessage2);
//		stringToLCD(mymessage3);
//		}
//		//stringToLCD(f);
//			++i;	
//	}
//	if (i ==6){
//		GPIOB ->ODR &=0XEFFF;
//		GPIOB ->ODR |=0XE000;
//		delay(time_delay);
//			if ((((temp= GPIOA ->IDR & GPIO_IDR_IDR5) >>5) &0x01) !=0x01){
//		stringToLCD(mymessage2);
//		stringToLCD(mymessage3);
//		}
//		GPIOB ->ODR &=0X1FFF;
//		GPIOB ->ODR |=0x0000;
//		
//			int temp=-1;
//			i=temp;

//	}
	
	//if (i ==7){
	//	GPIOB ->ODR &=0XEFFF;
	//	GPIOB ->ODR |=0XE000;
	//	delay(time_delay);
		
	//		int temp=0;
	//		i=temp;
			
	//}
}
}