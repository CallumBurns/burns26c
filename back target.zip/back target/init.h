#include <stdint.h>


void GPIO_init (void);
void ADC_Init(void);
void Clock_Init(void);
void PWM_Init(void);
void LCD_IO_init (void);
void LCD_Startup(void);
void delay(uint32_t count);
void CMD2LCD(uint8_t data);
void DM2LCD(uint8_t data);
void stringToLCD(char * message);