#include "stm32f10x.h"
#include "init.h"

void GPIO_init (){


	GPIOB -> CRH |= GPIO_CRH_MODE15;; // MSB of the multiplex1	(C)
	GPIOB -> CRH &= ~GPIO_CRH_CNF15; 
	
	GPIOB ->CRH |= GPIO_CRH_MODE14;		//middle bit of the multiplex1 (B)
	GPIOB ->CRH &= ~GPIO_CRH_CNF14; 
	
	GPIOB ->CRH |= GPIO_CRH_MODE13;		//LSB of the the multiplex 1 (A)
	GPIOB ->CRH &= ~GPIO_CRH_CNF13;
	
	
	GPIOB -> CRH |= GPIO_CRH_MODE12; // MSB of the multiplex2	(C)
	GPIOB -> CRH &= ~GPIO_CRH_CNF12;
	
	GPIOB ->CRH |= GPIO_CRH_MODE11;		//middle bit of the multiplex1 (B)
	GPIOB ->CRH &= ~GPIO_CRH_CNF11; 
	
	GPIOB ->CRH |= GPIO_CRH_MODE10;		//LSB of the the multiplex 1 (A)
	GPIOB ->CRH &= ~GPIO_CRH_CNF10;
	
//	
//	GPIOA ->CRL |= GPIO_CRL_MODE3;		//MSB of the multiplex 2 (c)
//	GPIOA ->CRL &= ~GPIO_CRL_CNF3; 
//	
//	GPIOA ->CRL |= GPIO_CRL_MODE4;		//MSB of the multiplex 2 (c)
//	GPIOA ->CRL &= ~GPIO_CRL_CNF4;
//	
//	GPIOA ->CRL |= GPIO_CRL_MODE7;		//MSB of the multiplex 2 (c)
//	GPIOA ->CRL &= ~GPIO_CRL_CNF7;
//	
	
	
	
	
}


//void ADC_Init(){
//	
//	RCC->APB2ENR |=  RCC_APB2ENR_AFIOEN | RCC_APB2ENR_IOPAEN | RCC_APB2ENR_ADC1EN;
//	GPIOA->CRL |= GPIO_CRL_MODE4 | GPIO_CRL_MODE3; // LEAVE THE MODE 2 AND 1 TO BE ZERO 
//  ADC1 ->CR2 =0X01;
//	
//	
//}


void Clock_Init(){

 uint32_t temp = 0x00;
    //If you hover over the RCC you can go to the definition and then
    //see it is a structure of all the RCC registers.  Then you can
    //simply assign a value.
    RCC->CFGR = 0x00050002;     // Output PLL/2 as MCO,
                                // PLLMUL X3, PREDIV1 is PLL input

    RCC->CR =  0x01010081;      // Turn on PLL, HSE, HSI

    while (temp != 0x02000000)  // Wait for the PLL to stabilize
    {
        temp = RCC->CR & 0x02000000; //Check to see if the PLL lock bit is set
    }

    //Enable peripheral clocks for various ports and subsystems
    //Bit 4: Port C Bit3: Port B Bit 2: Port A
	
    RCC->APB2ENR |=  RCC_APB2ENR_TIM1EN | RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPCEN | RCC_APB2ENR_AFIOEN;
		
	//GPIOA->CRH |=  GPIO_CRH_MODE12 | GPIO_CRH_MODE11 | GPIO_CRH_MODE10 | GPIO_CRH_MODE9 ; //intialization of the LEDS
	//GPIOA->CRH &= ~GPIO_CRH_CNF12 & ~GPIO_CRH_CNF11 & ~GPIO_CRH_CNF10 & ~GPIO_CRH_CNF9 ;
		
		

		//GPIOC ->CRH |= GPIO_CRH_MODE9 | GPIO_CRH_MODE8; //INTIALIZATION OF THE "LIGHTING" BOARD LED
		//GPIOC->CRH &= ~GPIO_CRH_CNF9 & ~GPIO_CRH_MODE8;
	

}


void LCD_IO_init (void)
{
   
    //Set the config and mode bits for Port C bits zero to seven and Port B bit 5,1,and 0 so they will
    // be push-pull outputs (up to 50 MHz)
    GPIOC->CRL |= GPIO_CRL_MODE7 | GPIO_CRL_MODE6 | GPIO_CRL_MODE5 | GPIO_CRL_MODE4 | GPIO_CRL_MODE3  | GPIO_CRL_MODE2 | GPIO_CRL_MODE1 | GPIO_CRL_MODE0;
    GPIOC->CRL &= ~GPIO_CRL_CNF7 & ~GPIO_CRL_CNF6 & ~GPIO_CRL_CNF5 & ~GPIO_CRL_CNF4 & ~GPIO_CRL_CNF3 & ~GPIO_CRL_CNF2 & ~GPIO_CRL_CNF1 & ~GPIO_CRL_CNF0 ;
		GPIOB->CRL |= GPIO_CRL_MODE5 | GPIO_CRL_MODE1 | GPIO_CRL_MODE0;
		GPIOB->CRL &= ~GPIO_CRL_CNF5 & ~GPIO_CRL_CNF1 & ~GPIO_CRL_CNF0;
}


void LCD_Startup(){
	
	delay(90000);
	CMD2LCD(0x38);
	delay(30000);
	CMD2LCD(0x38);
	delay(30000);
	CMD2LCD(0x38);
	delay(30000);
	CMD2LCD(0x38);
	delay(30000);
	CMD2LCD(0x0f);
	delay(30000);
	CMD2LCD(0x01);
	delay(30000);
	CMD2LCD(0X06);
	delay(30000);
}

void delay(uint32_t count)
{
    int i=0;
    for(i=0; i< count; ++i)
    {
    }
	}

void CMD2LCD(uint8_t data)
{
GPIOB->BSRR = 0x00210002; //LCD_CM_ENA; //RS low, E high
// GPIOC->ODR = data; //BAD: may affect upper bits on port C
GPIOC->ODR &= 0xFF00; //GOOD: clears the low bits without affecting high bits
GPIOC->ODR |= data; //GOOD: only affects lowest 8 bits of Port C
delay(8000);
GPIOB->BSRR =  0x00230000; //LCD_CM_DIS; //RS low, E low
delay(80000);
}


void DM2LCD(uint8_t data){
	
GPIOB->BSRR =   0x00210003; //LCD_DM_ENA; //RS low, E high
// GPIOC->ODR = data; //BAD: may affect upper bits on port C
GPIOC->ODR &= 0xFF00; //GOOD: clears the low bits without affecting high bits
GPIOC->ODR |= data; //GOOD: only affects lowest 8 bits of Port C
delay(8000);
GPIOB->BSRR = 0x00220001;  //LCD_DM_DIS; //RS low, E low
delay(80000);
	
}

void stringToLCD(char * message){
	int i=0;
	uint16_t messageLength = strlen(message);
	for (i=0; i<messageLength; ++i)
	{
		DM2LCD(*message);
		++message;
	}
}


	
	