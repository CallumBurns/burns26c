#include <stdint.h>


void GPIO_init (void);
void ADC_Init(void);
void Clock_Init(void);
void PWM_Init(void);
void LCD_IO_init (void);
void LCD_Startup(void);
void SignalOn1(void);
void delay(uint32_t count);
void Delay(uint16_t i);

#define GPIO_