#include "stm32f10x.h"
#include "Init.h"

void PWM_Init(void){
	
	TIM1->CR1 = TIM_CR1_CEN;
	TIM1->CCMR1 = TIM_CCMR1_CC1S_0 | TIM_CCER_CC1NP;
	TIM1->CR2 = TIM_CR2_OIS1;
	TIM1 ->EGR = TIM_EGR_UG;
	TIM1->CCMR1 = TIM_CCMR1_OC1M_2 | TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1PE | TIM_CCMR1_OC1FE;
	TIM1 ->CCER = TIM_CCER_CC1E;
	//TIM3->PSC = 2399;
	//TIM3->ARR =0Xfff;
	//TIM3->CCR1 = 0X7ff;
	TIM1->BDTR = TIM_BDTR_MOE | TIM_BDTR_OSSI;
	TIM1 ->CR1 = TIM_CR1_ARPE | TIM_CR1_CEN;

	
}

void GPIO_init (void){


	GPIOB -> CRH |= GPIO_CRH_MODE15; //INITIALIAZTION OF THE PULSE SIGNAL (Pb15)
	GPIOB -> CRH &= ~GPIO_CRH_CNF15;
	
	GPIOA -> CRL |= GPIO_CRL_MODE3;
	GPIOA -> CRL &= ~GPIO_CRL_CNF3;
	
	GPIOA -> CRL |= GPIO_CRH_MODE8;
	GPIOA -> CRL &= ~GPIO_CRH_CNF8;
	
	
	GPIOB ->CRL |= GPIO_CRL_MODE6;
	GPIOB ->CRL &= ~GPIO_CRL_CNF6;
	
	GPIOD ->CRL |= GPIO_CRL_MODE2;
	GPIOD -> CRL &= ~GPIO_CRL_MODE2;
	
	
	

	
	//GPIOB -> CRH &=~ GPIO_CRH_MODE10;
	//GPIOB -> CRH |= GPIO_CRH_CNF10_1; // PULL-UP/PULL DOWN INPUT PB10
 	
	//GPIOB -> CRH |= GPIO_CRH_MODE14 |GPIO_CRH_MODE14_0; //INITIALIAZTION OF THE PULSE SIGNAL (Pb15)
	//GPIOB -> CRH &= ~GPIO_CRH_CNF14;
	
//	
	//GPIOB -> CRH &= ~GPIO_CRH_MODE13; //INITIALIAZTION OF THE PULSE SIGNAL (Pb13)
	//GPIOB -> CRH &= ~GPIO_CRH_CNF13;

}


//void ADC_Init(){
	
	//RCC->APB2ENR |=  RCC_APB2ENR_AFIOEN | RCC_APB2ENR_IOPAEN | RCC_APB2ENR_ADC1EN;
	//GPIOA->CRL |= GPIO_CRL_MODE4 | GPIO_CRL_MODE3; // LEAVE THE MODE 2 AND 1 TO BE ZERO 
  //ADC1 ->CR2 =0X01;
	
	
//}

void LCD_IO_init (void)
{
   
    //Set the config and mode bits for Port C bits zero to seven and Port B bit 5,1,and 0 so they will
    // be push-pull outputs (up to 50 MHz)
    GPIOC->CRL |= GPIO_CRL_MODE7 | GPIO_CRL_MODE6 | GPIO_CRL_MODE5 | GPIO_CRL_MODE4 | GPIO_CRL_MODE3  | GPIO_CRL_MODE2 | GPIO_CRL_MODE1 | GPIO_CRL_MODE0;
    GPIOC->CRL &= ~GPIO_CRL_CNF7 & ~GPIO_CRL_CNF6 & ~GPIO_CRL_CNF5 & ~GPIO_CRL_CNF4 & ~GPIO_CRL_CNF3 & ~GPIO_CRL_CNF2 & ~GPIO_CRL_CNF1 & ~GPIO_CRL_CNF0 ;
		GPIOB->CRL |= GPIO_CRL_MODE5 | GPIO_CRL_MODE1 | GPIO_CRL_MODE0;
		GPIOB->CRL &= ~GPIO_CRL_CNF5 & ~GPIO_CRL_CNF1 & ~GPIO_CRL_CNF0;
}

void LCD_Startup(){
	
	delay(90000);
	CMD2LCD(0x38);
	delay(30000);
	CMD2LCD(0x38);
	delay(30000);
	CMD2LCD(0x38);
	delay(30000);
	CMD2LCD(0x38);
	delay(30000);
	CMD2LCD(0x0f);
	delay(30000);
	CMD2LCD(0x01);
	delay(30000);
	CMD2LCD(0X06);
	delay(30000);
}

void stringToLCD(char * message){
	int i=0;
	uint16_t messageLength = strlen(message);
	for (i=0; i<messageLength; ++i)
	{
		DM2LCD(*message);
		++message;
	}
}

void DM2LCD(uint8_t data){
	
GPIOB->BSRR =   0x00210003; //LCD_DM_ENA; //RS low, E high
// GPIOC->ODR = data; //BAD: may affect upper bits on port C
GPIOC->ODR &= 0xFF00; //GOOD: clears the low bits without affecting high bits
GPIOC->ODR |= data; //GOOD: only affects lowest 8 bits of Port C
delay(8000);
GPIOB->BSRR = 0x00220001;  //LCD_DM_DIS; //RS low, E low
delay(80000);
	
}

void CMD2LCD(uint8_t data)
{
GPIOB->BSRR = 0x00210002; //LCD_CM_ENA; //RS low, E high
// GPIOC->ODR = data; //BAD: may affect upper bits on port C
GPIOC->ODR &= 0xFF00; //GOOD: clears the low bits without affecting high bits
GPIOC->ODR |= data; //GOOD: only affects lowest 8 bits of Port C
delay(8000);
GPIOB->BSRR =  0x00230000; //LCD_CM_DIS; //RS low, E low
delay(80000);
}


void Clock_Init(){

 uint32_t temp = 0x00;
    //If you hover over the RCC you can go to the definition and then
    //see it is a structure of all the RCC registers.  Then you can
    //simply assign a value.
    RCC->CFGR = 0x00050002;     // Output PLL/2 as MCO,
                                // PLLMUL X3, PREDIV1 is PLL input

    RCC->CR =  0x01010081;      // Turn on PLL, HSE, HSI

    while (temp != 0x02000000)  // Wait for the PLL to stabilize
    {
        temp = RCC->CR & 0x02000000; //Check to see if the PLL lock bit is set
    }

    //Enable peripheral clocks for various ports and subsystems
    //Bit 4: Port C Bit3: Port B Bit 2: Port A
	
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPCEN | RCC_APB2ENR_IOPDEN;
		//RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
		
	GPIOA->CRH |=  GPIO_CRH_MODE12 | GPIO_CRH_MODE11 | GPIO_CRH_MODE10 | GPIO_CRH_MODE9 ; //intialization of the LEDS
	GPIOA->CRH &= ~GPIO_CRH_CNF12 & ~GPIO_CRH_CNF11 & ~GPIO_CRH_CNF10 & ~GPIO_CRH_CNF9 ;
		
		

		//GPIOC ->CRH |= GPIO_CRH_MODE9 | GPIO_CRH_MODE8; //INTIALIZATION OF THE "LIGHTING" BOARD LED
		//GPIOC->CRH &= ~GPIO_CRH_CNF9 & ~GPIO_CRH_MODE8;
	

}

void delay(uint32_t count)
{
    int i=0;
    for(i=0; i< count; ++i)
    {
    }
	}