#include "init.h"
#include "stm32f10x.h"
#include <stdio.h>

int main(){
Clock_Init();
GPIO_init();
//PWM_Init();
LCD_IO_init();
LCD_Startup();
int init=0;
int init1 =0;
int init2=0;
int init3=0;
int init4=0;	
int final =0;
int signal_up=60;
float distance=0;
float	distance1=0; 
float	distance2=0;
float	distance3=0;
float	distance4=0;
float average=0;
int signal_down =359940;
char Period1[50];
char Period2[50];
char Period3[50];
char Period4 [50];
char mymessage1[50]="Strike.FL!";
char mymessage2[50]="Strike.ML!";
char mymessage3[50]="Strike.MR!";
char mymessage4[50]="Strike.FR!";
char mymessage5[50]="                               "; //31 spaces

char Average [50];
int duration =1000000;

while(1){
	
	while(1){	
//		init =0;
//		GPIOB ->ODR |= 0x8000;
//		delay(signal_up);
//		GPIOB->ODR &= ~0x8000;
//		
//		while ((GPIOB ->IDR & GPIO_IDR_IDR14) != GPIO_IDR_IDR14){}
//		while	((GPIOB ->IDR & GPIO_IDR_IDR14) == GPIO_IDR_IDR14){
//			init++;
//			delay(6);
//		}
//		distance = init/29;   //(float)init*0.017+1821*2;
//		sprintf(Period1,"%f",distance);
//		stringToLCD(Period1);
//		//CMD2LCD(0x2D);
//		
//		
//		delay(signal_down);
		
		
	 init1 =0;
 init2=0;
 init3=0;
 init4=0;	
 distance1=0; 
 distance2=0;
	distance3=0;
	distance4=0;
		
		init1 =0;
		GPIOA ->ODR |= 0x8;
		delay(signal_up);
		GPIOA->ODR &= ~0x8;
	
		
		while ((GPIOA ->IDR & GPIO_IDR_IDR4) != GPIO_IDR_IDR4){}
		while	((GPIOA ->IDR & GPIO_IDR_IDR4) == GPIO_IDR_IDR4){
			GPIOA->ODR |=0X200; 
			init1++;
			delay(6);
		}
		distance1 = init1/29;   //(float)init*0.017+1821*2;
		
		//sprintf(Period1,"%f",distance1);
		//stringToLCD(Period1);
		//CMD2LCD(0x45);
		
		delay(signal_down);
		
		GPIOA ->ODR =~0X200;
		
		
			init2 =0;
		GPIOA ->ODR |= 0x100;
		delay(signal_up);
		GPIOA->ODR &= ~0x100;
	
		
		while ((GPIOA ->IDR & GPIO_IDR_IDR15) != GPIO_IDR_IDR15){}
		while	((GPIOA ->IDR & GPIO_IDR_IDR15) == GPIO_IDR_IDR15){
			GPIOA->ODR |=0X400;
			init2++;
			delay(6);
		}
		distance2 = init2/29;   //(float)init*0.017+1821*2;
//		
//		sprintf(Period2,"%f",distance2);
//		stringToLCD(Period2);
//		//CMD2LCD(0x32);
//		
		delay(signal_down);
		
		
		GPIOA ->ODR =~0X400;
		init3 =0;
		GPIOB ->ODR |= 0x40;
		delay(signal_up);
		GPIOB->ODR &= ~0x40;
	
		
		while ((GPIOB ->IDR & GPIO_IDR_IDR7) != GPIO_IDR_IDR7){}
		while	((GPIOB ->IDR & GPIO_IDR_IDR7) == GPIO_IDR_IDR7){
			GPIOA ->ODR |=0X800;
			init3++;
			delay(6);
		}
		distance3 = init3/52;   //(float)init*0.017+1821*2;
//		
//		sprintf(Period3,"%f",distance3);
//		stringToLCD(Period3);
		
		delay(signal_down);
		
		GPIOA->ODR =~0X600;
		init4 =0;
		//stringToLCD(b);
		//stringToLCD(d);
		GPIOC ->ODR |= 0x2000;
		delay(signal_up);
		GPIOB->ODR &= ~0x2000;
		//stringToLCD(c);
		//stringToLCD(d);
		//delay(signal_down);
		
		while ((GPIOD ->IDR & GPIO_IDR_IDR2) != GPIO_IDR_IDR2){}
		while	((GPIOD ->IDR & GPIO_IDR_IDR2) == GPIO_IDR_IDR2){
			///stringToLCD(test);
			GPIOA ->ODR =0X1000;
			init4++;
			delay(6);
		}
		distance4 =  init4/29;   //(float)init*0.017+1821*2;
		
		//sprintf(Period4,"%f",distance4);
		//stringToLCD(Period4);
//		//CMD2LCD(0x32);
//		
		delay(signal_down);
//	
		GPIOA ->ODR =~0X1000;
		average = ((distance1 + distance2 +distance3 +distance4)/4);
		
		sprintf(Average,"%f",average);
		stringToLCD(Average);
		stringToLCD(mymessage5);
		
		if (distance1 <28){
			
			stringToLCD(mymessage1);
			
		}
				if (distance2 <28){
			stringToLCD(mymessage2);
		}

		
			if (distance3 <28){
			stringToLCD(mymessage3);	
		}
			
		if (distance4 <28){
			stringToLCD(mymessage4);
		}
		
		}
	}
	}