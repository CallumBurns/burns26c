#include "stm32f10x.h"
#include "init.h"
#include <stdio.h>
#include <stdbool.h>
int main(){
int q =0;
char mymessage1[10]="Home:";
char mymessage2[10]="Away:";
char mymessage3[10]="S:";
char mymessage4[10]="B:";
char mymessage5[10]="O:";
char mymessage6[10]="I:";	
char mymessage7[10]="    ";//23456789";
char mymessage8[30]="                        ";	
char mymessage9[1]="T";
char mymessage10[1]="B";
char mymessage11[5]=" ";	
char mymessage12[2]="  ";
char mymessageAway[1];
char mymessageHome[1];
char Inning[1];
char Strikes[1];
char Balls[1];
char Outs[1];	
int HomeScore=0;
int AwayScore=0;
int InningNumber=1;
int Strikez=0;
int Ballz=0;
int Outz=0;
int IsTopBottom= 0; //where 0 will indicate if it is the top of the inning and 1 will represent the bottom of the inning.	


int inning=1;
int temp1=0;
int temp2=0;
int temp3=0;
int temp4=0;
int temp5 =0;
int counter1=-1;
int counter2=0;
int counter3=0;
int coutner4=0;
Clock_Init();
LCD_IO_init();
LCD_Startup();
while(1){
			stringToLCD(mymessage1);
			sprintf(mymessageHome,"%d",HomeScore);
			stringToLCD(mymessageHome);
			stringToLCD(mymessage7);
			stringToLCD(mymessage2);
			sprintf(mymessageAway,"%d",AwayScore);
			stringToLCD(mymessageAway);
			stringToLCD(mymessage8);
			stringToLCD(mymessage3);
			sprintf(Strikes,"%d",Strikez);
			stringToLCD(Strikes);
			stringToLCD(mymessage11);
			stringToLCD(mymessage4);
			sprintf(Balls,"%d",Ballz);
			stringToLCD(Balls);
			stringToLCD(mymessage11);
			stringToLCD(mymessage5);
			sprintf(Outs,"%d",Outz);
			stringToLCD(Outs);
			stringToLCD(mymessage11);
			stringToLCD(mymessage6);
			sprintf(Inning,"%d",InningNumber);
			stringToLCD(Inning);
			if (IsTopBottom %2 ==0){
				stringToLCD(mymessage9);
			}
			
			if (IsTopBottom %2 ==1){
				stringToLCD(mymessage10);
			}
			
			CMD2LCD(0x80);
			
			if ((((temp1 =GPIOA->IDR & GPIO_IDR_IDR5) >>5) &0X01) !=0X01){
			
				HomeScore++;
			
			
			}
			
			if ((((temp2 =GPIOC->IDR & GPIO_IDR_IDR12) >>12) &0X01) !=0X01){
			
				AwayScore++;
			
			
			}
			
			if ((((temp3 =GPIOB->IDR & GPIO_IDR_IDR8) >>8) &0X01) !=0X01){
			
				Strikez++;
				if (Strikez ==3){
				
					Strikez =0;
					Outz++;
				
				}
			}
			
				if((((temp4 =GPIOB->IDR & GPIO_IDR_IDR9) >>9) &0X01) !=0X01){
			
				Ballz++;
				if (Ballz ==4){
					Strikez=0;
					Ballz =0;
				
				} 
			}
				
			if 	((((temp5 = GPIOC ->IDR & GPIO_IDR_IDR10) >>10) &0X01) ==0X01){
			
						Strikez=0;
						Ballz=0;
			}
			
			
			if (Outz ==3){
					Outz=0;
					
					IsTopBottom++;
					if (IsTopBottom %2 == 0){
					
					InningNumber++;
					
					}
			
			}
		

		


}
}
