#include <stdint.h>
void LCD_IO_init (void);
void LCD_Startup(void);
void stringToLCD(char * message);
void DM2LCD(uint8_t data);
void CMD2LCD(uint8_t data);
void Clock_Init(void);
void delay(uint32_t count);
int start (void);





